const i=""+new URL("../assets/india.DUir8Hr0.png",import.meta.url).href;export{i};
