import{a as t}from"../chunks/entry.BPC0CFY8.js";export{t as start};
