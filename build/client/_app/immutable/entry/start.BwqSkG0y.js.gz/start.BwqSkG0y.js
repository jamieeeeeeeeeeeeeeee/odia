import{a as t}from"../chunks/entry.G7l-U3G6.js";export{t as start};
